//   TaskModel.fromJson(Map<String, dynamic> json) {
//     return TaskModel(
//       id: json['id'].toString(),
//       title: json['title'] ?? '',
//       customerName: json['customer_name'] ?? '',
//       taskStatus: json['status'] ?? '',
//     );
//   }
// }

int _parseInt(dynamic value) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  if (value is String) {
    final parsed = int.tryParse(value);
    return parsed ?? 0;
  }
  return 0;
}

String _parseString(dynamic value, String fallback) {
  if (value == null) return fallback;
  if (value is String) return value;
  return value.toString();
}

class TaskModel {
  final int id;
  final String title;
  final String leadId;
  final String followUpId;
  final String phone;
  final String location;
  final String status;

  TaskModel({
    required this.id,
    required this.title,
    required this.leadId,
    required this.followUpId,
    required this.phone,
    required this.location,
    required this.status,
  });

  factory TaskModel.fromJson(Map<String, dynamic> json) {
    return TaskModel(
      id: _parseInt(json['id']),
      title: _parseString(json['title'], 'Untitled Task'),
      leadId: _parseString(json['lead_id'], 'N/A'),
      followUpId: _parseString(json['followup_id'], 'N/A'),
      phone: _parseString(json['phone'], 'N/A'),
      location: _parseString(json['location'], 'N/A'),
      status: _parseString(json['status'], 'pending'),
    );
  }
}
