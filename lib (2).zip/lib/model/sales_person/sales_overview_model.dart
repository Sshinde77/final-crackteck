class DashboardData {
  final double target;
  final double achieved;
  final double pending;
  final List<Task> tasks;

  DashboardData({
    required this.target,
    required this.achieved,
    required this.pending,
    required this.tasks,
  });

  factory DashboardData.fromJson(Map<String, dynamic> json) {
    return DashboardData(
      target: _parseDouble(json['target']),
      achieved: _parseDouble(json['achieved']),
      pending: _parseDouble(json['pending']),
      tasks: _parseTaskList(json['tasks']),
    );
  }
}

class Task {
  final String title;
  final String leadId;
  final String followUpId;
  final String number;
  final String location;

  Task({
    required this.title,
    required this.leadId,
    required this.followUpId,
    required this.number,
    required this.location,
  });

  factory Task.fromJson(Map<String, dynamic> json) {
    return Task(
      title: json['title']?.toString() ?? '',
      leadId: json['lead_id']?.toString() ?? '',
      followUpId: json['follow_up_id']?.toString() ?? '',
      number: json['number']?.toString() ?? '',
      location: json['location']?.toString() ?? '',
    );
  }
}

double _parseDouble(dynamic value) {
  if (value == null) return 0.0;
  if (value is num) {
    final d = value.toDouble();
    if (d.isNaN || d.isInfinite) return 0.0;
    return d;
  }
  if (value is String) {
    final parsed = double.tryParse(value);
    if (parsed == null || parsed.isNaN || parsed.isInfinite) return 0.0;
    return parsed;
  }
  return 0.0;
}

List<Task> _parseTaskList(dynamic value) {
  if (value is List) {
    return value
        .whereType<Map<String, dynamic>>()
        .map((e) => Task.fromJson(e))
        .toList();
  }
  return <Task>[];
}
