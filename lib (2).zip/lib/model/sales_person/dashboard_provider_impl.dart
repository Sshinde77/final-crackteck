import 'package:final_crackteck/model/sales_person/notification_model.dart';
import 'package:final_crackteck/model/sales_person/sales_overview_model.dart';
import 'package:final_crackteck/model/sales_person/task_model.dart';
import 'package:final_crackteck/services/dashboard_service.dart';
import 'package:flutter/material.dart';

/// Provider for managing sales dashboard state and data
class DashboardProvider extends ChangeNotifier {
  DashboardData? sales;
  List<TaskModel> tasks = [];
  List<NotificationModel> notifications = [];

  bool loading = false;
  String? error;

  Future<void> _runWithLoading(Future<void> Function() action) async {
    loading = true;
    error = null;
    notifyListeners();

    try {
      await action();
    } catch (e) {
      error = e.toString();
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  Future<void> _runWithoutLoading(Future<void> Function() action) async {
    try {
      await action();
    } catch (e) {
      error = e.toString();
    } finally {
      notifyListeners();
    }
  }

  /// Load all dashboard data including sales overview, tasks, and notifications
  /// Uses the following endpoints:
  /// - GET /dashboard/{userId} for sales data
  /// - GET /task for tasks list
  /// - GET /notifications for notifications list
  Future<void> loadDashboard(String userId) async {
    await _runWithLoading(() async {
      // Fetch dashboard data (includes sales metrics)
      sales = await DashboardService.getDashboard(userId);

      // Fetch tasks list
      tasks = await DashboardService.getTasks();

      // Fetch notifications list
      notifications = await DashboardService.getNotifications();
    });
  }

  /// Load only sales overview data
  /// Uses GET /sales-overview endpoint
  Future<void> loadSalesOverview() async {
    await _runWithLoading(() async {
      sales = await DashboardService.getSalesOverview();
    });
  }

  /// Refresh tasks only
  Future<void> refreshTasks() async {
    await _runWithoutLoading(() async {
      tasks = await DashboardService.getTasks();
    });
  }

  /// Refresh notifications only
  Future<void> refreshNotifications() async {
    await _runWithoutLoading(() async {
      notifications = await DashboardService.getNotifications();
    });
  }
}
