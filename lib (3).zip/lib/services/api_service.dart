import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../constants/api_constants.dart';
import '../model/api_response.dart';
import '../core/secure_storage_service.dart';
import '../core/navigation_service.dart';

/// API Service for handling HTTP requests
class ApiService {
  ApiService._(); // Private constructor for singleton

  static final ApiService instance = ApiService._();

  // ---------------------------
  // Helper: safe JSON decode
  // ---------------------------
  Map<String, dynamic> _safeJsonDecode(String body) {
    try {
      final decoded = jsonDecode(body);
      if (decoded is Map<String, dynamic>) return decoded;
      return {
        'message': 'Server returned unexpected JSON format',
        'data': decoded,
      };
    } catch (_) {
      return {'message': 'Server returned non-JSON response', 'raw': body};
    }
  }

  // ---------------------------
  // Helper: common headers
  // ---------------------------
  Map<String, String> get _headers => const {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  };

  // ---------------------------
  // Helper: token persistence
  // ---------------------------
  Future<void> _persistTokensFromData(
    dynamic data, {
    required int roleId,
  }) async {
    if (data == null) {
      return;
    }

    String? accessToken;
    String? refreshToken;

    if (data is Map<String, dynamic>) {
      accessToken = _extractStringField(data, const [
        'access_token',
        'token',
        'accessToken',
      ]);
      refreshToken = _extractStringField(data, const [
        'refresh_token',
        'refreshToken',
      ]);
    } else if (data is String) {
      // Some APIs may return the token directly as a string.
      accessToken = data;
    }

    if (accessToken != null && accessToken.isNotEmpty) {
      await SecureStorageService.saveAccessToken(accessToken);
    }
    if (refreshToken != null && refreshToken.isNotEmpty) {
      await SecureStorageService.saveRefreshToken(refreshToken);
    }

    // Persist role so that refresh-token calls know which role_id to send.
    await SecureStorageService.saveRoleId(roleId);
  }

  String? _extractStringField(Map<String, dynamic> source, List<String> keys) {
    for (final key in keys) {
      final value = source[key];
      if (value is String && value.isNotEmpty) {
        return value;
      }
    }
    return null;
  }

  /// Login - Send OTP
  Future<ApiResponse> login({
    required int roleId,
    required String phoneNumber,
  }) async {
    try {
      debugPrint('🔵 API Request: POST ${ApiConstants.login}');
      debugPrint(
        '🔵 Request Body: {"role_id": $roleId, "phone_number": "$phoneNumber"}',
      );

      final response = await http
          .post(
            Uri.parse(ApiConstants.login),
            headers: _headers,
            body: jsonEncode({'role_id': roleId, 'phone_number': phoneNumber}),
          )
          .timeout(ApiConstants.requestTimeout);

      debugPrint('🟡 API Response Status: ${response.statusCode}');
      debugPrint('🟡 API Response Body: ${response.body}');

      final jsonResponse = _safeJsonDecode(response.body);

      // Success
      if (response.statusCode == 200 || response.statusCode == 201) {
        return ApiResponse(
          success: jsonResponse['success'] ?? true,
          message: jsonResponse['message'] ?? 'OTP sent',
          data: jsonResponse['data'],
          errors: jsonResponse['errors'],
        );
      }

      // Common "user not found / invalid" status codes
      if (response.statusCode == 404 || response.statusCode == 422) {
        return ApiResponse(
          success: false,
          message: jsonResponse['message'] ?? 'User not found',
          errors: jsonResponse['errors'],
        );
      }

      // Other server errors
      return ApiResponse(
        success: false,
        message:
            jsonResponse['message'] ?? 'Server error: ${response.statusCode}',
        errors: jsonResponse['errors'],
      );
    } on HandshakeException catch (e) {
      debugPrint('🔴 SSL Handshake Error: $e');
      return ApiResponse(success: false, message: 'SSL error: ${e.message}');
    } on SocketException catch (e) {
      debugPrint('🔴 No Internet / DNS Error: $e');
      return ApiResponse(
        success: false,
        message: 'No internet connection. Please check your network.',
      );
    } on http.ClientException catch (e) {
      debugPrint('🔴 ClientException: $e');
      return ApiResponse(
        success: false,
        message: 'Request failed: ${e.message}',
      );
    } on TimeoutException catch (e) {
      debugPrint('🔴 Timeout: $e');
      return ApiResponse(
        success: false,
        message: 'Request timeout. Please try again.',
      );
    } catch (e) {
      debugPrint('🔴 Unexpected Error: $e');
      return ApiResponse(success: false, message: 'Unexpected error: $e');
    }
  }

  /// Verify OTP
  Future<ApiResponse> verifyOtp({
    required int roleId,
    required String phoneNumber,
    required String otp,
  }) async {
    try {
      debugPrint('🔵 API Request: POST ${ApiConstants.verifyOtp}');
      debugPrint(
        '🔵 Request Body: {"role_id": $roleId, "phone_number": "$phoneNumber", "otp": "$otp"}',
      );

      final response = await http
          .post(
            Uri.parse(ApiConstants.verifyOtp),
            headers: _headers,
            body: jsonEncode({
              'role_id': roleId,
              'phone_number': phoneNumber,
              'otp': otp,
            }),
          )
          .timeout(ApiConstants.requestTimeout);

      debugPrint('🟡 API Response Status: ${response.statusCode}');
      debugPrint('🟡 API Response Body: ${response.body}');

      final jsonResponse = _safeJsonDecode(response.body);

      if (response.statusCode == 200 || response.statusCode == 201) {
        // Persist tokens (if present) for this role.
        await _persistTokensFromData(jsonResponse['data'], roleId: roleId);
        return ApiResponse(
          success: jsonResponse['success'] ?? true,
          message: jsonResponse['message'] ?? 'OTP verified',
          data: jsonResponse['data'],
          errors: jsonResponse['errors'],
        );
      }

      if (response.statusCode == 404 || response.statusCode == 422) {
        return ApiResponse(
          success: false,
          message: jsonResponse['message'] ?? 'Invalid OTP / user not found',
          errors: jsonResponse['errors'],
        );
      }

      return ApiResponse(
        success: false,
        message:
            jsonResponse['message'] ?? 'Server error: ${response.statusCode}',
        errors: jsonResponse['errors'],
      );
    } on HandshakeException catch (e) {
      debugPrint('🔴 SSL Handshake Error: $e');
      return ApiResponse(success: false, message: 'SSL error: ${e.message}');
    } on SocketException catch (e) {
      debugPrint('🔴 No Internet / DNS Error: $e');
      return ApiResponse(
        success: false,
        message: 'No internet connection. Please check your network.',
      );
    } on http.ClientException catch (e) {
      debugPrint('🔴 ClientException: $e');
      return ApiResponse(
        success: false,
        message: 'Request failed: ${e.message}',
      );
    } on TimeoutException catch (e) {
      debugPrint('🔴 Timeout: $e');
      return ApiResponse(
        success: false,
        message: 'Request timeout. Please try again.',
      );
    } catch (e) {
      debugPrint('🔴 Unexpected Error: $e');
      return ApiResponse(success: false, message: 'Unexpected error: $e');
    }
  }

  /// Refresh Token
  Future<ApiResponse> refreshToken({required int roleId}) async {
    try {
      debugPrint('🔵 API Request: POST ${ApiConstants.refreshToken}');
      debugPrint('🔵 Request Body: {"role_id": $roleId}');

      final currentAccessToken = await SecureStorageService.getAccessToken();
      final headers = Map<String, String>.from(_headers)
        ..addAll({
          if (currentAccessToken != null && currentAccessToken.isNotEmpty)
            'Authorization': 'Bearer $currentAccessToken',
        });

      final response = await http
          .post(
            Uri.parse(ApiConstants.refreshToken),
            headers: headers,
            body: jsonEncode({'role_id': roleId}),
          )
          .timeout(ApiConstants.requestTimeout);

      debugPrint('🟡 API Response Status: ${response.statusCode}');
      debugPrint('🟡 API Response Body: ${response.body}');

      final jsonResponse = _safeJsonDecode(response.body);

      if (response.statusCode == 200 || response.statusCode == 201) {
        // Persist any tokens contained in the refresh response.
        await _persistTokensFromData(jsonResponse['data'], roleId: roleId);
        return ApiResponse(
          success: jsonResponse['success'] ?? true,
          message: jsonResponse['message'] ?? 'Token refreshed',
          data: jsonResponse['data'],
          errors: jsonResponse['errors'],
        );
      }

      return ApiResponse(
        success: false,
        message: jsonResponse['message'] ?? 'Token refresh failed',
        errors: jsonResponse['errors'],
      );
    } on HandshakeException catch (e) {
      debugPrint('🔴 SSL Handshake Error: $e');
      return ApiResponse(success: false, message: 'SSL error: ${e.message}');
    } on SocketException {
      return ApiResponse(
        success: false,
        message: 'No internet connection. Please check your network.',
      );
    } on TimeoutException {
      return ApiResponse(
        success: false,
        message: 'Request timeout. Please try again.',
      );
    } catch (e) {
      debugPrint('🔴 Unexpected Error: $e');
      return ApiResponse(success: false, message: 'Unexpected error: $e');
    }
  }

  Future<ApiResponse> signup({
    required String name,
    required String phone,
    required String email,
    required String address,
    required String aadhar,
    required String pan,
    required File aadharFile,
    required File panFile,
  }) async {
    final uri = Uri.parse(ApiConstants.signup);

    final request = http.MultipartRequest("POST", uri)
      ..fields.addAll({
        "name": name,
        "phone": phone,
        "email": email,
        "address": address,
        "aadhar_no": aadhar,
        "pan_no": pan,
      })
      ..files.add(
        await http.MultipartFile.fromPath("aadhar_document", aadharFile.path),
      )
      ..files.add(
        await http.MultipartFile.fromPath("pan_document", panFile.path),
      );

    final response = await request.send();
    final resBody = await response.stream.bytesToString();

    final json = jsonDecode(resBody);
    return ApiResponse.fromJson(json, (data) => data);
  }

  /// Logout
  Future<ApiResponse> logout({required int roleId}) async {
    try {
      debugPrint('🔵 API Request: POST ${ApiConstants.logout}');
      debugPrint('🔵 Request Body: {"role_id": $roleId}');

      final response = await http
          .post(
            Uri.parse(ApiConstants.logout),
            headers: _headers,
            body: jsonEncode({'role_id': roleId}),
          )
          .timeout(ApiConstants.requestTimeout);

      debugPrint('🟡 API Response Status: ${response.statusCode}');
      debugPrint('🟡 API Response Body: ${response.body}');

      final jsonResponse = _safeJsonDecode(response.body);

      if (response.statusCode == 200 || response.statusCode == 201) {
        return ApiResponse(
          success: jsonResponse['success'] ?? true,
          message: jsonResponse['message'] ?? 'Logged out',
          data: jsonResponse['data'],
          errors: jsonResponse['errors'],
        );
      }

      return ApiResponse(
        success: false,
        message: jsonResponse['message'] ?? 'Logout failed',
        errors: jsonResponse['errors'],
      );
    } on HandshakeException catch (e) {
      debugPrint('🔴 SSL Handshake Error: $e');
      return ApiResponse(success: false, message: 'SSL error: ${e.message}');
    } on SocketException {
      return ApiResponse(
        success: false,
        message: 'No internet connection. Please check your network.',
      );
    } on TimeoutException {
      return ApiResponse(
        success: false,
        message: 'Request timeout. Please try again.',
      );
    } catch (e) {
      debugPrint('🔴 Unexpected Error: $e');
      return ApiResponse(success: false, message: 'Unexpected error: $e');
    }
  }

  // ========================================
  // Sales Dashboard API Methods
  // ========================================

  static const int _fallbackRoleIdForRefresh = 3; // Salesperson role id
  static const int _maxAuthRetries = 1;

  static bool _isUnauthorizedResponse(http.Response response) {
    if (response.statusCode == 401) return true;
    final bodyLower = response.body.toLowerCase();
    return bodyLower.contains('401') ||
        bodyLower.contains('unauthorized') ||
        bodyLower.contains('token not provided');
  }

  static Future<bool> _attemptTokenRefresh() async {
    final storedRoleId = await SecureStorageService.getRoleId();
    final roleId = storedRoleId ?? _fallbackRoleIdForRefresh;
    final api = ApiService.instance;
    final response = await api.refreshToken(roleId: roleId);
    return response.success;
  }

  static Future<void> _handleAuthFailure() async {
    await SecureStorageService.clearTokens();
    await NavigationService.navigateToAuthRoot();
  }

  static Future<http.Response> _performAuthenticatedGet(Uri url) async {
    int retryCount = 0;
    while (true) {
      final accessToken = await SecureStorageService.getAccessToken();
      final headers = <String, String>{
        'Accept': 'application/json',
        if (accessToken != null && accessToken.isNotEmpty)
          'Authorization': 'Bearer $accessToken',
      };

      final response = await http
          .get(url, headers: headers)
          .timeout(ApiConstants.requestTimeout);

      if (!_isUnauthorizedResponse(response)) {
        return response;
      }

      // Unauthorized
      if (retryCount >= _maxAuthRetries) {
        await _handleAuthFailure();
        return response;
      }

      retryCount++;
      final refreshed = await _attemptTokenRefresh();
      if (!refreshed) {
        await _handleAuthFailure();
        return response;
      }
      // Token refreshed successfully, loop will retry with new token.
    }
  }

  /// Fetch dashboard data for a specific user
  /// GET /dashboard/{userId}
  static Future<Map<String, dynamic>> fetchDashboard(String userId) async {
    final url = Uri.parse("${ApiConstants.dashboard}/$userId");

    try {
      debugPrint('🔵 API Request: GET $url');

      final response = await _performAuthenticatedGet(url);

      debugPrint('🟡 API Response Status: ${response.statusCode}');
      debugPrint('🟡 API Response Body: ${response.body}');

      if (response.statusCode == 200) {
        dynamic decoded;
        try {
          decoded = jsonDecode(response.body);
        } catch (_) {
          decoded = {
            'message': 'Server returned non-JSON',
            'raw': response.body,
          };
        }

        // Handle different response structures
        if (decoded is Map<String, dynamic> &&
            decoded.containsKey('data') &&
            decoded['data'] is Map<String, dynamic>) {
          return decoded['data'] as Map<String, dynamic>;
        }
        if (decoded is Map<String, dynamic>) return decoded;
        return {'data': decoded};
      } else {
        throw Exception(
          'Failed to load dashboard data: ${response.statusCode}',
        );
      }
    } on TimeoutException catch (e) {
      debugPrint('🔴 Timeout: $e');
      throw Exception('Request timeout. Please try again.');
    } on SocketException catch (e) {
      debugPrint('🔴 No Internet: $e');
      throw Exception('No internet connection. Please check your network.');
    } catch (e) {
      debugPrint('🔴 Error fetching dashboard: $e');
      throw Exception('Failed to load dashboard data: $e');
    }
  }

  /// Fetch sales overview data
  /// GET /sales-overview
  static Future<Map<String, dynamic>> fetchSalesOverview() async {
    final url = Uri.parse(ApiConstants.salesOverview);

    try {
      debugPrint('🔵 API Request: GET $url');

      final response = await _performAuthenticatedGet(url);

      debugPrint('🟡 API Response Status: ${response.statusCode}');
      debugPrint('🟡 API Response Body: ${response.body}');

      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);

        // Handle different response structures
        if (decoded is Map<String, dynamic> && decoded.containsKey('data')) {
          return decoded['data'] is Map<String, dynamic>
              ? decoded['data']
              : {'data': decoded['data']};
        }
        if (decoded is Map<String, dynamic>) return decoded;
        return {'data': decoded};
      } else {
        throw Exception(
          'Failed to load sales overview: ${response.statusCode}',
        );
      }
    } on TimeoutException catch (e) {
      debugPrint('🔴 Timeout: $e');
      throw Exception('Request timeout. Please try again.');
    } on SocketException catch (e) {
      debugPrint('🔴 No Internet: $e');
      throw Exception('No internet connection. Please check your network.');
    } catch (e) {
      debugPrint('🔴 Error fetching sales overview: $e');
      throw Exception('Failed to load sales overview: $e');
    }
  }

  /// Fetch tasks list
  /// GET /task
  static Future<List<dynamic>> fetchTasks() async {
    final url = Uri.parse(ApiConstants.task);

    try {
      debugPrint('🔵 API Request: GET $url');

      final response = await _performAuthenticatedGet(url);

      debugPrint('🟡 API Response Status: ${response.statusCode}');
      debugPrint('🟡 API Response Body: ${response.body}');

      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);

        // Handle different response structures
        if (decoded is Map<String, dynamic> && decoded.containsKey('data')) {
          return decoded['data'] is List ? decoded['data'] : [];
        }
        if (decoded is List) return decoded;
        return [];
      } else {
        throw Exception('Failed to load tasks: ${response.statusCode}');
      }
    } on TimeoutException catch (e) {
      debugPrint('🔴 Timeout: $e');
      throw Exception('Request timeout. Please try again.');
    } on SocketException catch (e) {
      debugPrint('🔴 No Internet: $e');
      throw Exception('No internet connection. Please check your network.');
    } catch (e) {
      debugPrint('🔴 Error fetching tasks: $e');
      throw Exception('Failed to load tasks: $e');
    }
  }

  /// Fetch notifications list
  /// GET /notifications
  static Future<List<dynamic>> fetchNotifications() async {
    final url = Uri.parse(ApiConstants.notifications);

    try {
      debugPrint('🔵 API Request: GET $url');

      final response = await _performAuthenticatedGet(url);

      debugPrint('🟡 API Response Status: ${response.statusCode}');
      debugPrint('🟡 API Response Body: ${response.body}');

      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);

        // Handle different response structures
        if (decoded is Map<String, dynamic> && decoded.containsKey('data')) {
          return decoded['data'] is List ? decoded['data'] : [];
        }
        if (decoded is List) return decoded;
        return [];
      } else {
        throw Exception('Failed to load notifications: ${response.statusCode}');
      }
    } on TimeoutException catch (e) {
      debugPrint('🔴 Timeout: $e');
      throw Exception('Request timeout. Please try again.');
    } on SocketException catch (e) {
      debugPrint('🔴 No Internet: $e');
      throw Exception('No internet connection. Please check your network.');
    } catch (e) {
      debugPrint('🔴 Error fetching notifications: $e');
      throw Exception('Failed to load notifications: $e');
    }
  }

  // ========================================
  // Generic HTTP Methods
  // ========================================

  /// Generic GET request
  static Future<dynamic> get(String url, {String? token}) async {
    try {
      final res = await http
          .get(
            Uri.parse(url),
            headers: {
              'Accept': 'application/json',
              if (token != null) 'Authorization': 'Bearer $token',
            },
          )
          .timeout(ApiConstants.requestTimeout);
      return jsonDecode(res.body);
    } catch (e) {
      debugPrint('🔴 GET Error: $e');
      rethrow;
    }
  }

  /// Generic POST request
  static Future<dynamic> post(String url, Map body, {String? token}) async {
    try {
      final headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        if (token != null) 'Authorization': 'Bearer $token',
      };

      final res = await http
          .post(Uri.parse(url), headers: headers, body: jsonEncode(body))
          .timeout(ApiConstants.requestTimeout);

      return jsonDecode(res.body);
    } catch (e) {
      debugPrint('🔴 POST Error: $e');
      rethrow;
    }
  }

  // Update Task View
  Future<ApiResponse> updateTaskStatus({
    required String taskId,
    required String status,
  }) async {
    final res = await http.post(
      Uri.parse("${ApiConstants.updateTaskStatus}/$taskId"),
      headers: _headers,
      body: {"status": status},
    );

    return ApiResponse.fromJson(jsonDecode(res.body), (data) => data);
  }
}
