import 'package:final_crackteck/screens/sales_person/sales_dashbord.dart';
import 'package:flutter/material.dart';


import '../login_screen.dart';
import '../role_screen.dart';
import 'app_routes.dart';
import 'package:final_crackteck/otp_screen.dart';
import 'package:final_crackteck/signup.dart';


/// Centralized route generator for the application
class RouteGenerator {
  RouteGenerator._(); // Private constructor to prevent instantiation

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case AppRoutes.roleSelection:
        return MaterialPageRoute(
          builder: (_) => const rolesccreen(),
          settings: settings,
        );

      case AppRoutes.login:
        final args = settings.arguments as LoginArguments?;
        if (args == null) {
          return _errorRoute('Login arguments missing');
        }
        return MaterialPageRoute(
          builder: (_) =>
              LoginScreen(roleId: args.roleId, roleName: args.roleName),
          settings: settings,
        );

        case AppRoutes.otpVerification:
        final args = settings.arguments as OtpArguments?;
        if (args == null) {
          return _errorRoute('OTP arguments missing');
        }
        return MaterialPageRoute(
          builder: (_) => OtpVerificationScreen(
            args: args,
          ),
          settings: settings,
        );

        case AppRoutes.signUp:
        final args = settings.arguments as SignUpArguments?;
        if (args == null) {
          return _errorRoute('Sign Up arguments missing');
        }
        return MaterialPageRoute(
          builder: (_) => SignupScreen(
            arg: args,
          ),
          settings: settings,
        );
        
        case AppRoutes.salespersonDashboard:
        return MaterialPageRoute(
          builder: (_) => SalespersonDashboard(),
          settings: settings,
        );


      default:
        return _errorRoute(settings.name);
    }
  }

  static Route<dynamic> _errorRoute(String? routeName) {
    return MaterialPageRoute(
      builder: (_) => Scaffold(
        appBar: AppBar(title: const Text('Error')),
        body: Center(child: Text('No route defined for $routeName')),
      ),
    );
  }
}

