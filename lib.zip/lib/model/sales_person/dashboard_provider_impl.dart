import 'package:final_crackteck/model/sales_person/notification_model.dart';
import 'package:final_crackteck/model/sales_person/sales_overview_model.dart';
import 'package:final_crackteck/model/sales_person/task_model.dart';
import 'package:final_crackteck/services/dashboard_service.dart';
import 'package:flutter/material.dart';

class DashboardProvider extends ChangeNotifier {
  DashboardData? sales;
  List<TaskModel> tasks = [];
  List<NotificationModel> notifications = [];

  bool loading = false;
  String? error;

  Future<void> loadDashboard(String userId, {String? token}) async {
    loading = true;
    error = null;
    notifyListeners();

    try {
      sales = await DashboardService.getSalesOverview(userId, token: token);
      tasks = await DashboardService.getTasks(token: token);
      notifications = await DashboardService.getNotifications(token: token);
    } catch (e) {
      error = e.toString();
    } finally {
      loading = false;
      notifyListeners();
    }
  }
}
