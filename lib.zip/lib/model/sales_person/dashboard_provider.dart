// import 'package:final_crackteck/model/sales_person/notification_model.dart';
// import 'package:final_crackteck/model/sales_person/sales_overview_model.dart';
// import 'package:final_crackteck/model/sales_person/task_model.dart';
// import 'package:final_crackteck/services/dashboard_service.dart';
// import 'package:flutter/material.dart';


// class DashboardProvider extends ChangeNotifier {
//   SalesOverview? sales;
//   List<TaskModel> tasks = [];
//   List<NotificationModel> notifications = [];

//   bool loading = true;

//   Future<void> loadDashboard(String type) async {
//     loading = true;
//     notifyListeners();

//     sales = await DashboardService.getSalesOverview(type);
//     tasks = await DashboardService.getTasks();
//     notifications = await DashboardService.getNotifications();

//     loading = false;
//     notifyListeners();
//   }
// }
