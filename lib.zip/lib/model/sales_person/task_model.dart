// class TaskModel {
//   final String title;
//   final String leadId;
//   final String followUpId;
//   final String phone;
//   final String location;

//   TaskModel.fromJson(Map<String, dynamic> json)
//       : title = json['title'] ?? '',
//         leadId = json['lead_id'] ?? '',
//         followUpId = json['followup_id'] ?? '',
//         phone = json['phone'] ?? '',
//         location = json['location'] ?? '';
// }
// class TaskModel {
//   final String id;
//   final String title;
//   final String customerName;
//   final String taskStatus;

//   TaskModel({
//     required this.id,
//     required this.title,
//     required this.customerName,
//     required this.taskStatus,
//   });

//   factory TaskModel.fromJson(Map<String, dynamic> json) {
//     return TaskModel(
//       id: json['id'].toString(),
//       title: json['title'] ?? '',
//       customerName: json['customer_name'] ?? '',
//       taskStatus: json['status'] ?? '',
//     );
//   }
// }

class TaskModel {
  final int id;
  final String title;
  final String leadId;
  final String followUpId;
  final String phone;
  final String location;
  final String status;

  TaskModel({
    required this.id,
    required this.title,
    required this.leadId,
    required this.followUpId,
    required this.phone,
    required this.location,
    required this.status,
  });

  factory TaskModel.fromJson(Map<String, dynamic> json) {
    return TaskModel(
      id: json['id'],
      title: json['title'],
      leadId: json['lead_id'],
      followUpId: json['followup_id'],
      phone: json['phone'],
      location: json['location'],
      status: json['status'],
    );
  }
}

