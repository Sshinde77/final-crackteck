class NotificationModel {
  final String title;
  final String message;
  final String time;

  NotificationModel.fromJson(Map<String, dynamic> json)
      : title = json['title'],
        message = json['message'],
        time = json['time'];
}
