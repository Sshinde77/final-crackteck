class DashboardData {
  final double target;
  final double achieved;
  final double pending;
  final List<Task> tasks;

  DashboardData({
    required this.target,
    required this.achieved,
    required this.pending,
    required this.tasks,
  });

  factory DashboardData.fromJson(Map<String, dynamic> json) {
    return DashboardData(
      target: (json['target'] ?? 0).toDouble(),
      achieved: (json['achieved'] ?? 0).toDouble(),
      pending: (json['pending'] ?? 0).toDouble(),
      tasks: (json['tasks'] as List)
          .map((e) => Task.fromJson(e))
          .toList(),
    );
  }
}

class Task {
  final String title;
  final String leadId;
  final String followUpId;
  final String number;
  final String location;

  Task({
    required this.title,
    required this.leadId,
    required this.followUpId,
    required this.number,
    required this.location,
  });

  factory Task.fromJson(Map<String, dynamic> json) {
    return Task(
      title: json['title'] ?? '',
      leadId: json['lead_id'] ?? '',
      followUpId: json['follow_up_id'] ?? '',
      number: json['number'] ?? '',
      location: json['location'] ?? '',
    );
  }
}
