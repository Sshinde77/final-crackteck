import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/gestures.dart';

import '../constants/app_colors.dart';
import '../constants/app_spacing.dart';
import '../services/api_service.dart';
import '../routes/app_routes.dart';

class SignupScreen extends StatefulWidget {
  final SignUpArguments arg;
  const SignupScreen({super.key, required this.arg});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final _formKey = GlobalKey<FormState>();
  final ApiService _apiService = ApiService.instance;

  final nameCtrl = TextEditingController();
  final numberCtrl = TextEditingController();
  final emailCtrl = TextEditingController();
  final addressCtrl = TextEditingController();
  final aadharCtrl = TextEditingController();
  final panCtrl = TextEditingController();

  File? aadharFile;
  File? panFile;

  bool agree = false;
  bool loading = false;

  Future<void> pickFile(bool isAadhar) async {
    final picker = ImagePicker();
    final file = await picker.pickImage(source: ImageSource.gallery);
    if (file == null) return;

    setState(() {
      if (isAadhar) {
        aadharFile = File(file.path);
      } else {
        panFile = File(file.path);
      }
    });
  }

  Future<void> signup() async {
    if (!_formKey.currentState!.validate()) return;
    if (!agree) {
      _snack("Please accept terms and conditions");
      return;
    }
    if (aadharFile == null || panFile == null) {
      _snack("Please upload required documents");
      return;
    }

    setState(() => loading = true);

    final res = await _apiService.signup(
      name: nameCtrl.text,
      phone: numberCtrl.text,
      email: emailCtrl.text,
      address: addressCtrl.text,
      aadhar: aadharCtrl.text,
      pan: panCtrl.text,
      aadharFile: aadharFile!,
      panFile: panFile!,
    );

    setState(() => loading = false);

    if (res.success) {
      _snack("Signup successful");
      Navigator.pop(context);
    } else {
      _snack(res.message ?? "Signup failed");
    }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.horizontalPadding,
          ),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 20),

                const Text(
                  "Hi, Welcome\nSales Person!",
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    height: 1.2,
                  ),
                ),

                const SizedBox(height: 10),
                const Text(
                  "Please sign up to continue",
                  style: TextStyle(color: Colors.grey),
                ),

                const SizedBox(height: 20),

                _input("Name", nameCtrl),
                _input(
                  "Number",
                  numberCtrl,
                  keyboard: TextInputType.phone,
                  prefix: "+91 ",
                ),
                _input(
                  "Email",
                  emailCtrl,
                  keyboard: TextInputType.emailAddress,
                ),
                _input("Address", addressCtrl),
                _input("Aadhar no.", aadharCtrl),
                _input("PAN no.", panCtrl),

                const SizedBox(height: 10),

                _uploadBox(
                  title: "Document",
                  subtitle: "Aadhar Card image in PNG or JPG (max. 2Mb)",
                  file: aadharFile,
                  onTap: () => pickFile(true),
                ),

                const SizedBox(height: 12),

                _uploadBox(
                  subtitle: "Pan Card image in PNG or JPG (max. 2Mb)",
                  file: panFile,
                  onTap: () => pickFile(false),
                ),

                const SizedBox(height: 15),

                Row(
                  children: [
                    Checkbox(
                      value: agree,
                      onChanged: (v) => setState(() => agree = v!),
                      activeColor: AppColors.primary,
                    ),
                    const Expanded(
                      child: Text(
                        "I agree to the terms and conditions",
                        style: TextStyle(fontSize: 13),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 10),

                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: loading ? null : signup,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: loading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : const Text(
                            "Sign Up",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                  ),
                ),

                const SizedBox(height: 15),
                Center(
                  child: RichText(
                    text: TextSpan(
                      style: const TextStyle(color: Colors.black),
                      children: [
                        const TextSpan(text: "Have an account? "),
                        TextSpan(
                          text: "Login",
                          style: const TextStyle(
                            color: AppColors.primary,
                            fontWeight: FontWeight.bold,
                          ),
                          recognizer: TapGestureRecognizer()
                            ..onTap = () {
                              Navigator.pushNamed(context, AppRoutes.login);
                            },
                        ),
                      ],
                    ),
                  ),
                ),

                // Center(
                //   child: RichText(
                //     text: const TextSpan(
                //       style: TextStyle(color: Colors.black),
                //       children: [
                //         TextSpan(text: "Have an account? "),
                //         TextSpan(
                //           text: "Login",
                //           style: TextStyle(
                //             color: AppColors.primary,
                //             fontWeight: FontWeight.bold,
                //           ),
                //         ),
                //       ],
                //     ),
                //   ),
                // ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _input(
    String hint,
    TextEditingController ctrl, {
    TextInputType keyboard = TextInputType.text,
    String? prefix,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: ctrl,
        keyboardType: keyboard,
        validator: (v) => v!.isEmpty ? "Required" : null,
        decoration: InputDecoration(
          hintText: hint,
          prefixText: prefix,
          filled: true,
          fillColor: Colors.grey.shade100,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }

  Widget _uploadBox({
    String? title,
    required String subtitle,
    required File? file,
    required VoidCallback onTap,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (title != null)
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text(
            subtitle,
            style: const TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 8),
          GestureDetector(
            onTap: onTap,
            child: Container(
              height: 45,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                border: Border.all(color: AppColors.primary),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                file == null ? "Click to upload" : "File selected",
                style: const TextStyle(
                  color: AppColors.primary,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
