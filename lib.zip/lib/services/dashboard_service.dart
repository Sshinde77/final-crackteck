import 'package:final_crackteck/constants/api_constants.dart';
import 'package:final_crackteck/model/sales_person/notification_model.dart';
import 'package:final_crackteck/model/sales_person/sales_overview_model.dart';
import 'package:final_crackteck/model/sales_person/task_model.dart';
import 'package:final_crackteck/services/api_service.dart';

class DashboardService {
  /// Fetch dashboard overview for given userId.
  /// Returns a [DashboardData] parsed from API response.
  static Future<DashboardData> getSalesOverview(
    String userId, {
    String? token,
  }) async {
    final res = await ApiService.fetchDashboard(userId, token: token);
    return DashboardData.fromJson(res);
  }

  /// Fetch list of tasks.
  static Future<List<TaskModel>> getTasks({String? token}) async {
    final res = await ApiService.get(ApiConstants.task, token: token);
    final list = (res is Map && res.containsKey('data')) ? res['data'] : res;
    return (list as List).map((e) => TaskModel.fromJson(e)).toList();
  }

  /// Fetch list of notifications.
  static Future<List<NotificationModel>> getNotifications({
    String? token,
  }) async {
    final res = await ApiService.get(ApiConstants.notifications, token: token);
    final list = (res is Map && res.containsKey('data')) ? res['data'] : res;
    return (list as List).map((e) => NotificationModel.fromJson(e)).toList();
  }
}

// }
